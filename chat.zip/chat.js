const kBaseUrl = "https://api.deepseek.com";
const kChatCompletionsPath = "/chat/completions";
const kModel = "deepseek-chat";

const API_KEY = "sk-67470a479b234e7a81fec56a2316c47d";

const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");

const trialModalEl = document.getElementById("trialOverModal");
const goLoginBtn = document.getElementById("goLoginBtn");
let trialModal = null;

/* =======================
   ✅ Chat Persistence
======================= */
const STORAGE_KEY = "nk_chat_state_v1";

function saveChatState() {
  try {
    const state = {
      conversation,
      html: chatBox?.innerHTML || "",
      ts: Date.now()
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error("Save Chat Failed", e);
  }
}

function loadChatState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    console.error("Load Chat Failed", e);
    return null;
  }
}

function restoreChatState() {
  const state = loadChatState();
  if (!state) return;

  // Restore UI
  if (chatBox && typeof state.html === "string") {
    chatBox.innerHTML = state.html;
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  // Restore Conversation
  if (Array.isArray(state.conversation) && state.conversation.length) {
    conversation.length = 0;
    state.conversation.forEach((m) => conversation.push(m));
  }
}

/* =======================
   ✅ Trial UI Handling
======================= */
function lockChatUI() {
  userInput.disabled = true;
  sendBtn.disabled = true;
  userInput.placeholder = "Trial Ended. Please Login...";
}

function showTrialOverPopup() {
  lockChatUI();
  if (trialModalEl) {
    if (!trialModal) trialModal = new bootstrap.Modal(trialModalEl);
    trialModal.show();
  }
}

function checkTrialOnLoad() {
  // UI already restored before this call
  if (isTrialOver()) showTrialOverPopup();
}

goLoginBtn?.addEventListener("click", () => {
  // ✅ Save chat before redirecting to login
  saveChatState();
  localStorage.setItem("nk_redirect_after_login", "chat.html");
  window.location.href = "login.html";
});

/* =======================
   ✅ Language Detection
======================= */
function detectLang(text) {
  const t = (text || "").trim();

  if (/[\u0980-\u09FF]/.test(t)) return "Bengali";
  if (/[\u0A80-\u0AFF]/.test(t)) return "Gujarati";
  if (/[\u0B00-\u0B7F]/.test(t)) return "Odia";
  if (/[\u0B80-\u0BFF]/.test(t)) return "Tamil";
  if (/[\u0D00-\u0D7F]/.test(t)) return "Malayalam";
  if (/[\u0A00-\u0A7F]/.test(t)) return "Punjabi";
  if (/[\u0600-\u06FF]/.test(t)) return "Urdu";

  if (/[\u0900-\u097F]/.test(t)) {
    const marathiHints = ["आहे", "नाही", "काय", "कसा", "कशी", "कुठे", "झाले", "होते", "करा", "म्हणजे"];
    if (marathiHints.some((w) => t.includes(w))) return "Marathi";

    const bhojpuriHints = ["रउआ", "हमनी", "तोहरा", "तोहके", "कइसे", "कइसन", "कहाँ", "भइल", "होखे", "देवे", "जाई", "बाटे"];
    if (bhojpuriHints.some((w) => t.includes(w))) return "Bhojpuri";

    return "Hindi";
  }

  if (/[A-Za-z]/.test(t)) return "English";
  return "English";
}

/* =======================
   ✅ Conversation State
======================= */
const conversation = [
  {
    role: "system",
    content:
      "You are Nkosh AI, an agriculture assistant for Indian farmers. Response must be 3 to 4 lines only. Plain text only. Do not use any special characters like *, #, -, •, bullets, numbering, or markdown. IMPORTANT: Always follow the latest system instruction that says 'Reply strictly in <LANG>'. Do not mix languages."
  }
];

/* =======================
   ✅ UI Helpers
======================= */
function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function addMessage(text, sender) {
  const div = document.createElement("div");
  div.className = sender === "user" ? "mb-2 text-end" : "mb-2 text-start";
  const bubbleClass = sender === "user" ? "chat-bubble user" : "chat-bubble bot";

  div.innerHTML = `
    <div class="d-inline-block px-3 py-2 rounded-4 ${bubbleClass}" style="animation: fadeUp .25s ease;">
      ${escapeHtml(text)}
    </div>
  `;

  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;

  // ✅ Persist UI + conversation snapshot frequently
  saveChatState();
}

/* =======================
   ✅ API Call
======================= */
async function callDeepSeek(messages) {
  if (!API_KEY) throw new Error("Missing API Key");

  const response = await fetch(`${kBaseUrl}${kChatCompletionsPath}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`
    },
    body: JSON.stringify({
      model: kModel,
      messages,
      temperature: 0.7
    })
  });

  const data = await response.json();

  if (!response.ok) {
    const msg = data?.error?.message || data?.message || "Error Connecting To Server";
    throw new Error(msg);
  }

  return data?.choices?.[0]?.message?.content?.trim() || "No response received";
}

/* =======================
   ✅ Trim Conversation Safely
======================= */
const MAX_MSGS = 14;

function trimConversation() {
  if (!Array.isArray(conversation) || conversation.length <= 1) return;

  const base = [conversation[0]]; // keep first system always
  const rest = conversation.slice(1);

  // keep last MAX_MSGS items from rest
  const keep = rest.slice(-MAX_MSGS);

  conversation.length = 0;
  conversation.push(...base, ...keep);
}

/* =======================
   ✅ Send Message
======================= */
async function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  if (isTrialOver()) {
    showTrialOverPopup();
    return;
  }

  addMessage(message, "user");
  userInput.value = "";
  addMessage("Typing...", "bot");

  try {
    const lang = detectLang(message);

    conversation.push({
      role: "system",
      content: `Reply strictly in ${lang} only. If ${lang} is Bhojpuri, reply in pure Bhojpuri (not Hindi). Plain text only. 3 to 4 lines only. No bullets, no numbering, no symbols like *, #, -, •.`
    });

    conversation.push({ role: "user", content: message });
    saveChatState();

    const reply = await callDeepSeek(conversation);

    // remove typing bubble
    chatBox.lastChild?.remove();

    conversation.push({ role: "assistant", content: reply });
    addMessage(reply, "bot");

    trimConversation();
    saveChatState();

    const result = consumeTrialOnce();
    if (result.over) {
      showTrialOverPopup();
      return;
    }
  } catch (error) {
    // remove typing bubble
    chatBox.lastChild?.remove();

    if (String(error?.message || "").toLowerCase().includes("missing api key")) {
      addMessage("API Key Missing. Please Add DeepSeek API Key In chat.js", "bot");
    } else {
      addMessage("Error Connecting To Server", "bot");
    }

    console.error(error);
  }
}

/* =======================
   ✅ Events
======================= */
sendBtn.addEventListener("click", sendMessage);
userInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") sendMessage();
});

/* =======================
   ✅ On Load: Restore + Trial Check
======================= */
restoreChatState();
checkTrialOnLoad();